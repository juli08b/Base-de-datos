-- BASE DE DATOS
CREATE DATABASE IF NOT EXISTS Entidad;
USE Entidad;

-- TABLA: DEPARTAMENTOS
CREATE TABLE departamentos (
    id_departamento INT AUTO_INCREMENT PRIMARY KEY,
    nombre_departamento VARCHAR(100) NOT NULL
);

-- TABLA: CARGOS (CORREGIDA: se agregó salario)
CREATE TABLE cargos (
    id_cargo INT AUTO_INCREMENT PRIMARY KEY,
    nombre_cargo VARCHAR(100) NOT NULL,
    salario DECIMAL(10,2) NOT NULL
);

-- TABLA: EMPLEADOS (CORREGIDO el orden)
CREATE TABLE empleados (
    id_empleado INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    genero VARCHAR(10),
    correo VARCHAR(60),
    fecha_contratacion DATE,
    id_departamento INT,
    id_cargo INT,
    FOREIGN KEY (id_departamento) REFERENCES departamentos(id_departamento),
    FOREIGN KEY (id_cargo) REFERENCES cargos(id_cargo)
);

-- TABLA: PROYECTOS
CREATE TABLE proyectos (
    id_proyecto INT AUTO_INCREMENT PRIMARY KEY,
    nombre_proyecto VARCHAR(150) NOT NULL
);

-- TABLA INTERMEDIA: EMPLEADO_PROYECTO
CREATE TABLE empleado_proyecto (
    id_empleado INT,
    id_proyecto INT,
    PRIMARY KEY (id_empleado, id_proyecto),
    FOREIGN KEY (id_empleado) REFERENCES empleados(id_empleado),
    FOREIGN KEY (id_proyecto) REFERENCES proyectos(id_proyecto)
);
