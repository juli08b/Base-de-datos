SELECT * FROM departamento;
SELECT * FROM cargos;
SELECT * FROM empleados;
